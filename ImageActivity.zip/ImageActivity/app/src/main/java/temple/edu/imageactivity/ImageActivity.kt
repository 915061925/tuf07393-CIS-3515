package temple.edu.imageactivity

import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

class ImageActivity : AppCompatActivity(), ImageAdapter.ImageOperations {

    private lateinit var dogName: TextView
    private lateinit var dogImg: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_image)

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)
        dogName = findViewById(R.id.dog_name)
        dogImg = findViewById(R.id.dog_img)

        //setting a grid layout manager for recyclerview
        recyclerView.layoutManager =  GridLayoutManager(this, 4)

        //creating a list of images and names
        val imgList = listOf(R.drawable.dog1, R.drawable.dog2, R.drawable.dog3, R.drawable.dog4,
            R.drawable.dog5, R.drawable.dog6, R.drawable.dog7, R.drawable.dog8, R.drawable.dog9, R.drawable.dog10, R.drawable.dog11, R.drawable.dog12)

        val dogNames = listOf("MAX", "KOBE", "OSCAR", "COOPER", "OAKLEY", "CHARLIE", "RUDY", "BAILEY", "WALTER", "BLAZE", "BENTLEY", "JASPER")

        //setting recyclerview adapter and passing name and image list
        recyclerView.adapter = ImageAdapter(imgList, dogNames, this)

    }

    override fun onImageClicked(name: String, img: Int) {
        //when image is clicked in recyclerview set image and name
        dogName.text = name
        dogImg.setImageResource(img)
    }
}