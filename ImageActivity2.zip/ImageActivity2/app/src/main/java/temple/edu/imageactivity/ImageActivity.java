package temple.edu.imageactivity;

import android.app.Activity;

public class ImageActivity extends Activity {
}
