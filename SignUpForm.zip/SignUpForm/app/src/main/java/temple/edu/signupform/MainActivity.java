package temple.edu.signupform;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText editName, editEmail, editPassword, editConfirmPassword;
    private TextView txtErrorName, txtErrorEmail, txtErrorPassword, txtErrorConfirmPassword;
    public String name, email, password, confirmPassword = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
    }

    private void init() {
        editName = findViewById(R.id.editTextName);
        editEmail = findViewById(R.id.editTextEmail);
        editConfirmPassword = findViewById(R.id.editTextConfirmPassword);
        editPassword = findViewById(R.id.editTextPassword);
        txtErrorName = findViewById(R.id.txtErrorName);
        txtErrorEmail = findViewById(R.id.txtErrorEmail);
        txtErrorPassword = findViewById(R.id.txtErrorPassword);
        txtErrorConfirmPassword = findViewById(R.id.txtErrorConfirmPassword);
    }

    public void save(View view) {
        name = editName.getText().toString();
        email = editEmail.getText().toString();
        password = editPassword.getText().toString();
        confirmPassword = editConfirmPassword.getText().toString();

        if (name.equals(""))
            txtErrorName.setVisibility(View.VISIBLE);
        else
            txtErrorName.setVisibility(View.GONE);
        if (email.equals(""))
            txtErrorEmail.setVisibility(View.VISIBLE);
        else
            txtErrorEmail.setVisibility(View.GONE);
        if (password.equals(""))
            txtErrorPassword.setVisibility(View.VISIBLE);
        else
            txtErrorPassword.setVisibility(View.GONE);
        if (confirmPassword.equals("")) {
            txtErrorConfirmPassword.setText(R.string.cnf_pass);
            txtErrorConfirmPassword.setVisibility(View.VISIBLE);
        } else {
            txtErrorConfirmPassword.setText(R.string.password_does_not_match);
            txtErrorConfirmPassword.setVisibility(View.GONE);
        }
        if (!confirmPassword.equals(password))
            txtErrorConfirmPassword.setVisibility(View.VISIBLE);
        else
            txtErrorConfirmPassword.setVisibility(View.GONE);
        if (!name.equals("") && !email.equals("") && !password.equals("") && confirmPassword.equals(password)) {
            Toast.makeText(this, "Welcome, " + name + ", to the SignUpForm App", Toast.LENGTH_LONG).show();
        }
    }
}